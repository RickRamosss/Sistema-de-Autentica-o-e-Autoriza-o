package com.example.jwt_restapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtRestapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
